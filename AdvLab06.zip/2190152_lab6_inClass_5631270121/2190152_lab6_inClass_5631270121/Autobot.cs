﻿using System;

namespace _lab6_inClass_5631270121
{
	class Autobot :Cybertron
	{
		private int spirit; 
		public Autobot (int life,int x,int y,bool isVehicle,int spirit) : base (life,x,y,isVehicle)
		{
			setSpirit (spirit);
		}


		public override void moveHorizontal(int x){
			int x_new = getPosition ().x + x + spirit;
			if(x_new > 500 || x_new < 0) {
				if (x_new > 500) {
					x_new = 500;
				} else {
					x_new = 0;
				}

			};
			setPosition(new Point(x_new,getPosition().y));
		}

		public override void moveVertical(int y){
			int y_new = getPosition ().y + y + spirit;
			if(y_new > 500 || y_new < 0) {
				if (y_new > 500) {
					y_new = 500;
				} else {
					y_new = 0;
				}
			};
			setPosition (new Point (getPosition ().x, y_new));
		}
		public void transform(){
			Console.WriteLine("Autobot transform");
			setIsVehicle (!getIsVehicle ());
			Console.WriteLine ("After a transform the value for isVehicle is " + getIsVehicle ());

		}

		public void setSpirit(int spirit){
			if(spirit > 10 || spirit < 0) {
				if (spirit > 10) {
					Console.Write ("Too much spirit: ");
				} else {
					Console.Write ("Negative spirit: ");
				}
				spirit = 5;
				Console.WriteLine (spirit);
			};
			this.spirit = spirit;
		}

		public int getSpirit(){
			return this.spirit;
		}
	}
}

