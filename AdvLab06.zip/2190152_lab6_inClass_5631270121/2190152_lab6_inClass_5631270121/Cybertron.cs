﻿using System;

namespace _lab6_inClass_5631270121
{
	abstract class Cybertron 
	{
		private int life;
		private Point position;
		private bool isVehicle;

		public Cybertron (int life,int x,int y,bool isVehicle){

			setLife (life);
			setPosition (new Point (x, y));
			setIsVehicle (isVehicle);
		}

		public abstract void moveHorizontal(int x);

		public abstract void moveVertical(int y);

		public void transform(){

			Console.WriteLine ("After a transform the value for isVehicle is " + getIsVehicle ());
		}

		public void setLife(int life){
			if(life > 20 || life < 0) {
				if (life > 20) {
					Console.Write ("Excess Life: ");
				} else {
					Console.Write ("Negative Life: ");
				}
				life = 20;
				Console.WriteLine (life);
			};
			this.life = life;
		}
		public int getLife(){
			return this.life;
		}
		public void setPosition(Point p){
			if(p.x > 500 || p.x < 0) {
				if (p.x > 500) {
					Console.Write ("Too large x: ");
				} else {
					Console.Write ("Negative x: ");
				}
				p.x = 500;
				Console.WriteLine (p.x);
			};
			if(p.y > 500 || p.y < 0) {
				if (p.y > 500) {
					Console.Write ("Too large y: ");
				} else {
					Console.Write ("Negative y: ");
				}
				p.y = 500;
				Console.WriteLine (p.y);
			};

			this.position = p;
		}
		public Point getPosition(){
			return this.position;
		}

		public void setIsVehicle(bool isVehicle){
			this.isVehicle = isVehicle;
		}

		public bool getIsVehicle(){
			return this.isVehicle;
		}

	}






	// The Point class is derived from System.Object. 
	public class Point 
	{
		public int x, y;

		public Point(int x, int y) 
		{
			this.x = x;
			this.y = y;
		}

		public override bool Equals(object obj) 
		{
			// If this and obj do not refer to the same type, then they are not equal. 
			if (obj.GetType() != this.GetType()) return false;

			// Return true if  x and y fields match.
			Point other = (Point) obj;
			return (this.x == other.x) && (this.y == other.y);
		}

		// Return the XOR of the x and y fields. 
		public override int GetHashCode() 
		{
			return x ^ y;
		}

		// Return the point's value as a string. 
		public override String ToString() 
		{
			return String.Format("({0}, {1})", x, y);
		}

		// Return a copy of this point object by making a simple field copy. 
		public Point Copy() 
		{
			return (Point) this.MemberwiseClone();
		}
	}
}

