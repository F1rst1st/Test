﻿using System;
//5631270121 Benjaporn Pianphanitporn


namespace _lab6_inClass_5631270121
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Autobot a = new Autobot (4, 15, 20, false, 5); 
			Console.WriteLine (a.getLife ());
			Console.WriteLine (a.getPosition ().x);
			Console.WriteLine (a.getPosition ().y); 
			Console.WriteLine (a.getIsVehicle());
			Console.WriteLine (a.getSpirit ());

			a = new Autobot(-1, 15, 20, false, 5); //then print out the life point using get method.
			a = new Autobot(21, 15, 20, false, 5); //then print out the life point using get method.
			a = new Autobot(4, -1, 20, false, 5); //then print out the x position using get method.
			a = new Autobot(4, 501, 20, false, 5); //then print out the x position using get method.
			a = new Autobot(4, 15, -1, false, 5); //then print out the y position using get method.
			a = new Autobot(4, 15, 501, false, 5); //then print out the y position using get method.
			a = new Autobot(4, 15, 20, false, -1); //then print out the spirit value using get method.
			a = new Autobot(4, 15, 20, false, 11); //then print out the spirit value using get method.
			a.transform ();
			a.transform ();

			a = new Autobot (10, 250, 250, false, 5);
			a.moveHorizontal (5);
			Console.WriteLine ("A moved X Position is :"+a.getPosition ().x);
			a = new Autobot (10, 250, 250, false, 5);
			a.moveVertical (5);
			Console.WriteLine ("A moved Y Position is :"+a.getPosition ().y);
			a = new Autobot (10, 250, 250, false, 5);
			a.moveHorizontal (-500000);
			Console.WriteLine ("A moved X Position is :"+a.getPosition ().x);
			a = new Autobot (10, 250, 250, false, 5);
			a.moveHorizontal (50000000);
			Console.WriteLine ("A moved X Position is :"+a.getPosition ().x);
		}
	}
}
